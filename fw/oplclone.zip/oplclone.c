#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <dos.h>

void writeopl(int r, int v)
{
    int i;
    outp(0x388, r);
    for (i = 0; i < 6; i++)
    {
        inp(0x388);
    }
    outp(0x389, v);
    for (i = 0; i < 36; i++)
    {
        inp(0x388);
    }
}

int readopl(void)
{
    return inp(0x388);
}


int detectopl(void)
{
    int stat1, stat2,i;
    writeopl(0x04, 0x60);
    writeopl(0x04, 0x80);
    stat1 = readopl();
    writeopl(0x02, 0xff);
    writeopl(0x04, 0x21);
    for (i = 0; i < 200; i++)
    {
        readopl();
    }
    stat2 = readopl();
    writeopl(0x04, 0x60);
    writeopl(0x04, 0x80);
    if ((stat1 & 0xe0) == 0 && (stat2 & 0xe0) == 0xc0)
    {
        return 1;
    }
    return 0;
}

void resetopl(void)
{
    int i;
    for (i = 0x20; i < 0xff; i++)
    {
        if ((i & 0xe0) == 0x80)
        {
            writeopl(i, 0x0f);
        }
        else
        {
            writeopl(i, 0x00);
        }
    }
    delay(40);
}

int main(int argc, char *argv[])
{
    if (detectopl())
    {
        printf("OPL is detected\n");
    }
    else
    {
        printf("OPL is not detected\n");
        return 0;
    }
    printf("Reset chip\n");
    resetopl();
    printf("Set patch\n");
    writeopl(0x20, 0x03);
    writeopl(0x23, 0x01);
    writeopl(0x40, 0x2f);
    writeopl(0x43, 0x00);
    writeopl(0x61, 0x10);
    writeopl(0x63, 0x10);
    writeopl(0x80, 0x00);
    writeopl(0x83, 0x00);
    writeopl(0xa0, 0x44);
    writeopl(0xb0, 0x12);
    writeopl(0xc0, 0xfe);
    printf("Start voice\n");
    writeopl(0xb0, 0x32);
    delay(1);
    writeopl(0x60, 0xf0);
    printf("If you hear sine wave you have a real OPL3 or very accurate clone,\notherwise you have OPL clone.\nPress any key to close program.\n");
    getch();
    resetopl();
    return 0;
}
